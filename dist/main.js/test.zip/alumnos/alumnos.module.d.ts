export declare class AlumnosModule {
}
