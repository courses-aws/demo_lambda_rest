export declare class AlumnosService {
    create(alumnoData: any): Promise<any>;
    findAll(): Promise<any[]>;
}
